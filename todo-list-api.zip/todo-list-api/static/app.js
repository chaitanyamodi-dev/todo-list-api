// ...existing code...
const API_URL = "/todos";

let todos = [];
let currentFilter = "all";
let editingTodoId = null;
let isProcessing = false;

document.addEventListener("DOMContentLoaded", () => {
  setupEvents();
  loadTodos();
  setTodayLabel();
});

function setupEvents() {
  const form = document.getElementById("todoForm");
  const addBtn = document.getElementById("addTodoBtn");
  const titleInput = document.getElementById("todoTitle");
  const descInput = document.getElementById("todoDescription");
  const searchInput = document.getElementById("searchInput");
  const todoList = document.getElementById("todoList");
  const editModal = document.getElementById("editModal");

  form?.addEventListener("submit", (e) => {
    e.preventDefault();
    createTodo();
  });

  addBtn?.addEventListener("click", createTodo);

  titleInput?.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      createTodo();
    }
  });

  descInput?.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      createTodo();
    }
  });

  searchInput?.addEventListener("input", () => {
    renderTodos();
  });

  document.querySelectorAll(".filter-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      currentFilter = btn.dataset.filter;
      document.querySelectorAll(".filter-btn").forEach((el) => {
        el.classList.toggle("active", el === btn);
      });
      renderTodos();
    });
  });

  todoList?.addEventListener("click", (event) => {
    const toggleBtn = event.target.closest(".btn-toggle");
    const editBtn = event.target.closest(".btn-edit");
    const deleteBtn = event.target.closest(".btn-delete");
    const item = event.target.closest(".todo-item");

    if (!item) return;

    const id = Number(item.dataset.id);

    if (toggleBtn) return toggleTodo(id);
    if (editBtn) return openEditModal(id);
    if (deleteBtn) return deleteTodo(id);
  });

  document.getElementById("saveEditBtn")?.addEventListener("click", saveEdit);
  document.getElementById("cancelEditBtn")?.addEventListener("click", closeEditModal);
  document.getElementById("closeEditModal")?.addEventListener("click", closeEditModal);

  editModal?.addEventListener("click", (e) => {
    if (e.target === editModal) closeEditModal();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && editModal && !editModal.classList.contains("hidden")) {
      closeEditModal();
    }
  });
}

function setTodayLabel() {
  const el = document.querySelector(".eyebrow");
  if (!el) return;

  const date = new Date();
  const options = { weekday: "long", month: "short", day: "numeric" };
  el.textContent = date.toLocaleDateString("en-US", options);
}

async function loadTodos() {
  const list = document.getElementById("todoList");
  if (!list) return;

  list.innerHTML = `
    <div class="empty-state">
      <i class="ph ph-spinner ph-spin"></i>
      <p>Loading tasks...</p>
    </div>
  `;

  try {
    const res = await fetch(API_URL);
    if (!res.ok) throw new Error("Load failed");

    todos = await res.json();
    renderTodos();
    updateStats();
  } catch (error) {
    list.innerHTML = `
      <div class="empty-state">
        <i class="ph ph-warning-circle"></i>
        <h3>Unable to load tasks</h3>
        <p>Check if the backend is running.</p>
      </div>
    `;
    showToast("Failed to load tasks.", "error");
  }
}

async function createTodo() {
  if (isProcessing) return;

  const titleInput = document.getElementById("todoTitle");
  const descInput = document.getElementById("todoDescription");
  const addBtn = document.getElementById("addTodoBtn");

  const title = titleInput.value.trim();
  const description = descInput.value.trim();

  if (!title) {
    titleInput.focus();
    showToast("Please enter a task title.", "warning");
    return;
  }

  isProcessing = true;
  addBtn.disabled = true;
  addBtn.innerHTML = '<i class="ph ph-spinner ph-spin"></i> Adding...';

  try {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title,
        description: description || null,
        completed: false
      })
    });

    if (!res.ok) throw new Error("Create failed");

    const newTodo = await res.json();
    todos.unshift(newTodo);

    titleInput.value = "";
    descInput.value = "";
    renderTodos();
    updateStats();
    showToast("Task added successfully.", "success");
  } catch (error) {
    showToast("Task could not be created.", "error");
  } finally {
    isProcessing = false;
    addBtn.disabled = false;
    addBtn.innerHTML = '<i class=\"ph ph-plus-circle\"></i> Add task';
  }
}

async function toggleTodo(id) {
  const todo = todos.find((item) => item.id === id);
  if (!todo) return;

  const oldState = todo.completed;

  todo.completed = !todo.completed;
  renderTodos();
  updateStats();

  try {
    const res = await fetch(`${API_URL}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: todo.title,
        description: todo.description || null,
        completed: todo.completed
      })
    });

    if (!res.ok) throw new Error("Update failed");

    const updated = await res.json();
    todos = todos.map((item) => (item.id === updated.id ? updated : item));
    renderTodos();
    updateStats();
  } catch (error) {
    todo.completed = oldState;
    renderTodos();
    updateStats();
    showToast("Could not update task status.", "error");
  }
}

async function deleteTodo(id) {
  if (!confirm("Delete this task?")) return;

  const original = [...todos];
  todos = todos.filter((item) => item.id !== id);

  renderTodos();
  updateStats();

  try {
    const res = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
    if (!res.ok) throw new Error("Delete failed");
    showToast("Task deleted.", "success");
  } catch (error) {
    todos = original;
    renderTodos();
    updateStats();
    showToast("Could not delete this task.", "error");
  }
}

function openEditModal(id) {
  const todo = todos.find((item) => item.id === id);
  if (!todo) return;

  editingTodoId = id;

  document.getElementById("editTitle").value = todo.title || "";
  document.getElementById("editDescription").value = todo.description || "";
  document.getElementById("editCompleted").checked = !!todo.completed;

  document.getElementById("editModal").classList.remove("hidden");
  document.getElementById("editTitle").focus();
}

function closeEditModal() {
  editingTodoId = null;
  document.getElementById("editModal").classList.add("hidden");
}

async function saveEdit() {
  if (!editingTodoId) return;

  const title = document.getElementById("editTitle").value.trim();
  if (!title) {
    showToast("Title cannot be empty.", "warning");
    return;
  }

  const todo = todos.find((item) => item.id === editingTodoId);
  if (!todo) return;

  const updated = {
    ...todo,
    title,
    description: document.getElementById("editDescription").value.trim() || null,
    completed: document.getElementById("editCompleted").checked
  };

  try {
    const res = await fetch(`${API_URL}/${updated.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: updated.title,
        description: updated.description,
        completed: updated.completed
      })
    });

    if (!res.ok) throw new Error("Save failed");

    const serverTodo = await res.json();
    todos = todos.map((item) => (item.id === serverTodo.id ? serverTodo : item));

    renderTodos();
    updateStats();
    closeEditModal();
    showToast("Changes saved.", "success");
  } catch (error) {
    showToast("Could not save changes.", "error");
  }
}

function renderTodos() {
  const container = document.getElementById("todoList");
  if (!container) return;

  const searchValue = (document.getElementById("searchInput")?.value || "").trim().toLowerCase();

  const filtered = todos.filter((todo) => {
    const matchesFilter =
      currentFilter === "all" ||
      (currentFilter === "active" && !todo.completed) ||
      (currentFilter === "completed" && todo.completed);

    const matchesSearch =
      !searchValue ||
      `${todo.title || ""} ${todo.description || ""}`.toLowerCase().includes(searchValue);

    return matchesFilter && matchesSearch;
  });

  if (!filtered.length) {
    container.innerHTML = `
      <div class="empty-state">
        <i class="ph ph-clipboard-text"></i>
        <h3>No tasks found</h3>
        <p>Try another search or create a new one.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map((todo) => {
    const done = todo.completed ? "completed" : "";
    const icon = todo.completed
      ? '<i class="ph ph-check-circle" style="color: var(--success);"></i>'
      : '<i class="ph ph-circle" style="color: var(--muted);"></i>';

    return `
      <div class="todo-item ${done}" data-id="${todo.id}">
        <div class="todo-content">
          <button class="icon-btn btn-toggle" type="button" aria-label="Toggle task">
            ${icon}
          </button>

          <div class="todo-text">
            <h4>${escapeHtml(todo.title || "Untitled task")}</h4>
            ${todo.description ? `<p>${escapeHtml(todo.description)}</p>` : ""}
          </div>
        </div>

        <div class="todo-actions">
          <button class="icon-btn btn-edit" type="button" aria-label="Edit task">
            <i class="ph ph-pencil-simple"></i>
          </button>
          <button class="icon-btn btn-delete" type="button" aria-label="Delete task">
            <i class="ph ph-trash"></i>
          </button>
        </div>
      </div>
    `;
  }).join("");
}

function updateStats() {
  const total = todos.length;
  const completed = todos.filter((t) => t.completed).length;
  const pending = total - completed;
  const percent = total ? Math.round((completed / total) * 100) : 0;

  setNumber("totalTasks", total);
  setNumber("completedTasks", completed);
  setNumber("pendingTasks", pending);

  const heroBadge = document.querySelector(".hero-badge strong");
  if (heroBadge) heroBadge.textContent = `${percent}%`;
}

function setNumber(id, value) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = value;
}

function showToast(message, type = "info") {
  const toast = document.createElement("div");
  toast.className = `toast ${type}`;
  toast.innerHTML = `<i class="ph ${type === "success" ? "ph-check-circle" : type === "error" ? "ph-warning-circle" : "ph-info"}"></i><span>${message}</span>`;
  document.body.appendChild(toast);

  requestAnimationFrame(() => {
    toast.style.opacity = "1";
    toast.style.transform = "translateY(0)";
  });

  setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translateY(20px)";
    setTimeout(() => toast.remove(), 200);
  }, 2200);
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}