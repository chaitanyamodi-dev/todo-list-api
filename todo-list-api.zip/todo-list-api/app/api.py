from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.schemas.todo import TodoCreate, TodoResponse, TodoUpdate
from app.services.todo_service import TodoService

router = APIRouter(prefix="/todos", tags=["todos"])


@router.post(
    "",
    response_model=TodoResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a todo",
)
def create_todo(todo: TodoCreate, db: Session = Depends(get_db)):
    return TodoService.create_todo(db, todo)


@router.get(
    "",
    response_model=list[TodoResponse],
    summary="Get all todos",
)
def get_todos(db: Session = Depends(get_db)):
    return TodoService.get_all_todos(db)


@router.get(
    "/{todo_id}",
    response_model=TodoResponse,
    summary="Get a todo by ID",
)
def get_todo(todo_id: int, db: Session = Depends(get_db)):
    todo = TodoService.get_todo_by_id(db, todo_id)
    if not todo:
        raise HTTPException(status_code=404, detail="Todo not found")
    return todo


@router.put(
    "/{todo_id}",
    response_model=TodoResponse,
    summary="Update a todo",
)
def update_todo(todo_id: int, todo_data: TodoUpdate, db: Session = Depends(get_db)):
    updated_todo = TodoService.update_todo(db, todo_id, todo_data)
    if not updated_todo:
        raise HTTPException(status_code=404, detail="Todo not found")
    return updated_todo


@router.delete(
    "/{todo_id}",
    status_code=status.HTTP_200_OK,
    summary="Delete a todo",
)
def delete_todo(todo_id: int, db: Session = Depends(get_db)):
    deleted = TodoService.delete_todo(db, todo_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Todo not found")
    return {"message": "Todo deleted successfully", "status": "success"}
