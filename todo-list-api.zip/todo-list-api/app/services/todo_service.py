from sqlalchemy.orm import Session

from app.models.todo import Todo
from app.schemas.todo import TodoCreate, TodoUpdate


class TodoService:
    @staticmethod
    def create_todo(db: Session, todo_data: TodoCreate):
        todo = Todo(
            title=todo_data.title,
            description=todo_data.description,
            completed=todo_data.completed,
        )
        db.add(todo)
        db.commit()
        db.refresh(todo)
        return todo

    @staticmethod
    def get_all_todos(db: Session):
        return db.query(Todo).order_by(Todo.id.desc()).all()

    @staticmethod
    def get_todo_by_id(db: Session, todo_id: int):
        return db.query(Todo).filter(Todo.id == todo_id).first()

    @staticmethod
    def update_todo(db: Session, todo_id: int, todo_data: TodoUpdate):
        todo = db.query(Todo).filter(Todo.id == todo_id).first()
        if not todo:
            return None

        for field, value in todo_data.model_dump(exclude_unset=True).items():
            setattr(todo, field, value)

        db.commit()
        db.refresh(todo)
        return todo

    @staticmethod
    def delete_todo(db: Session, todo_id: int):
        todo = db.query(Todo).filter(Todo.id == todo_id).first()
        if not todo:
            return False

        db.delete(todo)
        db.commit()
        return True
