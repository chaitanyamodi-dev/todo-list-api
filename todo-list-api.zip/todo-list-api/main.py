from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import router
from app.core.database import Base, engine
from app.models.todo import Todo

Base.metadata.create_all(bind=engine)


app = FastAPI(
    title="TodoFlow Premium API",
    version="1.0.0",
    description="A premium todo API with CRUD support and rich API documentation.",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)
