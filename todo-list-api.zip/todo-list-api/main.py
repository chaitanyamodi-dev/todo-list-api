from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from fastapi.responses import FileResponse
from app.api import router
from app.core.database import Base, engine
from app.models.todo import Todo

# Create database tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="TodoFlow Premium API",
    version="1.0.0",
    description="A premium Todo management API built with FastAPI.",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)

# Serve frontend
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def home():
    return FileResponse("static/index.html")
